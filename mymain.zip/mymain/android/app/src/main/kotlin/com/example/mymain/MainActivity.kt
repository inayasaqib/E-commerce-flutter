package com.example.mymain

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
