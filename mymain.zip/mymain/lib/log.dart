import 'package:flutter/material.dart';
import 'package:mymain/signup.dart';
import 'package:mymain/succesful.dart';

class Log extends StatefulWidget {
  const Log({super.key});

  @override
  State<Log> createState() => _LogState();
}

class _LogState extends State<Log> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  bool emailValid = false;

  void validateemail(String email) {
    setState(() {
       emailValid = email.isNotEmpty && email.endsWith('@gmail.com');
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
      ),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "SoleMate",
              style: TextStyle(
                fontSize: 30,
                color: Colors.black,
                fontStyle: FontStyle.italic,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 30.0),
            const Text(
              "Welcome!",
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 20.0,
              ),
            ),
            const Text(
              "Please login or signup to continue our app",
              style: TextStyle(
                fontSize: 15.0,
                color: Color.fromARGB(255, 168, 166, 166),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 50.0),
              child: TextField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  suffixIcon: emailValid
                      ? const Icon(Icons.check)
                      : null,
                  errorText: emailValid ? null : 'Please Enter Valid Gmail Adress',
                ),
                onChanged: (email) => validateemail(email),
              ),
            ),
            Container(
                padding: const EdgeInsets.symmetric(horizontal: 50.0),
              child: TextField(
                controller: passwordController,
                decoration: const InputDecoration(
                  labelText: 'Password',
                ),
              ),
            ),
            const  SizedBox(height: 20,),
            ElevatedButton(onPressed: emailValid? (){
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> const Succesful()));
            } :null, 
            style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black,  shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0), 
                ),
                textStyle: const TextStyle(fontSize: 20),
                minimumSize: const Size(250, 50)
                ),
              child: const Text('Login'), ),
            const  SizedBox(height: 15, child: Text("Or", style: TextStyle(color: Color.fromARGB(255, 168, 166, 166),fontSize: 10),),),
                  ElevatedButton(
              onPressed: () {
                   Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> const Signup()));
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.black, foregroundColor: Colors.white,  shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0), 
                ),
                textStyle: const TextStyle(fontSize: 20),
                minimumSize: const Size(250, 50)
                ),
              child: const Text('Sign Up'),
            ),
          ],
        ),
      ),
    );
  }
}