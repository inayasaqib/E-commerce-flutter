import 'package:flutter/material.dart';

class PopularTwo extends StatefulWidget {
  const PopularTwo({super.key});

  @override
  State<PopularTwo> createState() => _PopularTwoState();
}

class _PopularTwoState extends State<PopularTwo> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}