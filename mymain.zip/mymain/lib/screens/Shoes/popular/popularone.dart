import 'package:flutter/material.dart';

class PopularOne extends StatefulWidget {
  const PopularOne({super.key});

  @override
  State<PopularOne> createState() => _PopularOneState();
}

class _PopularOneState extends State<PopularOne> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}