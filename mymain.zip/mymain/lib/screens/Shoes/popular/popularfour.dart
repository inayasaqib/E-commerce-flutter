import 'package:flutter/material.dart';

class PopularFour extends StatefulWidget {
  const PopularFour({super.key});

  @override
  State<PopularFour> createState() => _PopularFourState();
}

class _PopularFourState extends State<PopularFour> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}