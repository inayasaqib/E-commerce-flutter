import 'package:flutter/material.dart';

class AllTwo extends StatefulWidget {
  const AllTwo({super.key});

  @override
  State<AllTwo> createState() => _AllTwoState();
}

class _AllTwoState extends State<AllTwo> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}