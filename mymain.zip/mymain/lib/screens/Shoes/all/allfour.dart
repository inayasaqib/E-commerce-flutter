import 'package:flutter/material.dart';

class AllFour extends StatefulWidget {
  const AllFour({super.key});

  @override
  State<AllFour> createState() => _AllFourState();
}

class _AllFourState extends State<AllFour> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}