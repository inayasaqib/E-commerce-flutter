// ignore_for_file: prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';
import 'package:mymain/screens/cartview.dart';
import 'package:mymain/screens/favscreen.dart';

class ALLone extends StatefulWidget {
  const ALLone({Key? key}) : super(key: key);

  @override
  State<ALLone> createState() => _ALLoneState();
}

class _ALLoneState extends State<ALLone> {
  List cartItems = [];
  List favItems = [];

  void goToCartScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CartView(items: cartItems),
      ),
    );
  }

  void goToFavScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Favourite(fav: favItems),
      ),
    );
  }

  void addToCart(item) {
    cartItems.add(item);
    setState(() {});
  }

  void addtofav(items) {
    favItems.add(items);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text(
          "SoleMate",
          style: TextStyle(fontWeight: FontWeight.bold, fontStyle: FontStyle.italic),
        ),
        actions: [
          IconButton(
            onPressed: goToCartScreen,
            icon: const Icon(Icons.add_shopping_cart, color: Colors.black),
          ),
          IconButton(
            onPressed: goToFavScreen,
            icon: const Icon(Icons.favorite, color: Colors.black),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          color: const Color.fromARGB(255, 203, 202, 200),
          child: SizedBox(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Center(
                    child: Column(
                      children: [
                        Image.network(
                          'https://m.media-amazon.com/images/I/61T0ZyKia4L._AC_UY1000_.jpg',
                          width: 300,
                          height: 300,
                        ),
                      const  SizedBox(height: 20),
                     const    Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                               Text(
                                'Clementine Satchel',
                                style: TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
