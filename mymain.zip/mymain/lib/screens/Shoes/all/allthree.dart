import 'package:flutter/material.dart';

class AllThree extends StatefulWidget {
  const AllThree({super.key});

  @override
  State<AllThree> createState() => _AllThreeState();
}

class _AllThreeState extends State<AllThree> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}