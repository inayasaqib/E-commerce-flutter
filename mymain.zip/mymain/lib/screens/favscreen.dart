import 'package:flutter/material.dart';

class Favourite extends StatefulWidget {
  List fav = [];
  Favourite({super.key, required this.fav});

  @override
  State<Favourite> createState() => _FavouriteState();
}

class _FavouriteState extends State<Favourite> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blue,
      ),
      body: ListView.builder(
        itemCount: widget.fav.length,
        itemBuilder: (context, index) {
          return ListTile(
            tileColor: Colors.grey,
            title: Text("${widget.fav[index]}"),
            trailing: IconButton(
              onPressed: () {
                widget.fav.removeAt(index);
                setState(() {});
              },
              icon: const Icon(Icons.delete),
            ),
          );
        },
      ),
    );
  }
}