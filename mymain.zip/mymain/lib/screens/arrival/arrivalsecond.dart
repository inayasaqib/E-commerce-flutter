import 'package:flutter/material.dart';

class ArrivalSecond extends StatefulWidget {
  const ArrivalSecond({super.key});

  @override
  State<ArrivalSecond> createState() => _ArrivalSecondState();
}

class _ArrivalSecondState extends State<ArrivalSecond> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}