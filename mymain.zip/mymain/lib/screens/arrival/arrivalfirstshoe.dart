import 'package:flutter/material.dart';

class ArrivalFisrt extends StatefulWidget {
  const ArrivalFisrt({super.key});

  @override
  State<ArrivalFisrt> createState() => _ArrivalFisrtState();
}

class _ArrivalFisrtState extends State<ArrivalFisrt> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      body: Text("First"),
    );
  }
}