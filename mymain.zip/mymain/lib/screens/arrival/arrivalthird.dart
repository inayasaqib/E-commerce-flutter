import 'package:flutter/material.dart';

class ArrivalThird extends StatefulWidget {
  const ArrivalThird({super.key});

  @override
  State<ArrivalThird> createState() => _ArrivalThirdState();
}

class _ArrivalThirdState extends State<ArrivalThird> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}