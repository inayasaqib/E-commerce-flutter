import 'package:flutter/material.dart';

class ArrivalFourth extends StatefulWidget {
  const ArrivalFourth({super.key});

  @override
  State<ArrivalFourth> createState() => _ArrivalFourthState();
}

class _ArrivalFourthState extends State<ArrivalFourth> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}