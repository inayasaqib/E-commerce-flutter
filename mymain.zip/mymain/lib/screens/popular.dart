import 'package:flutter/material.dart';
import 'package:mymain/screens/Shoes/all/alltwo.dart';
import 'package:mymain/screens/Shoes/popular/popularone.dart';
import 'package:mymain/screens/arrival/arrivalfour.dart';
import 'package:mymain/screens/Shoes/popular/popularfour.dart';
import 'package:mymain/screens/Shoes/popular/popularthree.dart';
import 'package:mymain/screens/Shoes/popular/populartwo.dart';
import 'package:mymain/screens/cartview.dart';
import 'package:mymain/screens/favscreen.dart';

class Popular extends StatefulWidget {
  const Popular({super.key});

  @override
  State<Popular> createState() => _PopularState();
}

class _PopularState extends State<Popular> {
   List cartItems = [];
  List favItems = [];

  void goToCartScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => CartView(items: cartItems),
      ),
    );
  }

  void goToFavScreen() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => Favourite(fav: favItems),
      ),
    );
  }

  void addToCart(item) {
    cartItems.add(item);
    setState(() {});
  }

  void addtofav(items) {
    favItems.add(items);
    setState(() {});
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
       appBar: AppBar(
        backgroundColor: Colors.white,
        title: const Text(
          "SoleMate",
          style: TextStyle(fontWeight: FontWeight.bold, fontStyle: FontStyle.italic),
        ),
        actions: [
          IconButton(
            onPressed: goToCartScreen,
            icon: const Icon(Icons.add_shopping_cart, color: Colors.black),
          ),
          IconButton(
            onPressed: goToFavScreen,
            icon: const  Icon(Icons.favorite, color: Colors.black),
          ),
        ],
      ) ,
        body: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
             const  Padding(padding: EdgeInsets.symmetric(horizontal: 30.0, vertical: 10.0),
               child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                 children: [
                   Text("Popular", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),),
                 ],
               ),
              ),
              const  SizedBox(height: 5),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildArrivalItem(context, 'https://www.servis.pk/cdn/shop/files/M-CH-0100279.jpg?v=1702968123&width=1280', 'Cobalt Cruise', 'Sustainable Skate Shoe', '95.00', const PopularOne()),
                  _buildArrivalItem(context, 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTnafxYmqT5rq23YCzVdL_u9PemBhmdu4ctiw&usqp=CAU', 'Sugar PlumPop', 'Whimsical Everyday Bag', '75.00',const PopularTwo()),
                  _buildArrivalItem(context, 'https://i.ebayimg.com/images/g/9m4AAOSwHGJcDtn0/s-l1600.jpg', 'Night Stalker', 'Tech-Fusion BasketBall Shoe', '120.00', const PopularThree()),
                ],
              ),
            ),
           const   SizedBox(height: 5),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildArrivalItem(context, 'https://i.ebayimg.com/images/g/MWEAAOSwc09j62sv/s-l400.jpg', 'TrainBlazer', 'All-Terrain Boot', '140.00', const PopularFour()),
                  _buildArrivalItem(context, "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT5wNaEhSQ8Id3vu60Hv9YgclmMA3-LBciFKQ&usqp=CAU","Rustic Hideaway","Vintage Leather Bi-Fold Wallet","80.00", const ArrivalFourth()),
                  _buildArrivalItem(context, "https://www.pegai.com/cdn/shop/products/AMZMTN3.jpg?v=1652832228&width=1080","Bold Stripe","Bi-Fold Leather Wallet","65.00", const AllTwo() )
                ],
              ),
            ),
            ],
          ),
        ),
    );
  }
}

Widget _buildArrivalItem(BuildContext context, String imageUrl, String title, String subtitle, String price, Widget destinationScreen) {
    return InkWell(
      onTap: () {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => destinationScreen));
      },
      child: Container(
        width: 275,
        margin: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 15.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              height: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10.0),
                image: DecorationImage(
                  image: NetworkImage(imageUrl),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 5),
            Text(
              title,
              style: const TextStyle(color: Colors.black, fontSize: 15, fontWeight: FontWeight.bold),
            ),
            Text(
              subtitle,
              style: const TextStyle(color: Color.fromARGB(255, 190, 187, 180), fontSize: 10),
            ),
            Text(
              price,
              style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.black),
            ),
          ],
        ),
      ),
    );
  }