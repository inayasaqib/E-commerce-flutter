import 'package:flutter/material.dart';
import 'package:mymain/homepage.dart';

class Succesful extends StatefulWidget {
  const Succesful({super.key});

  @override
  State<Succesful> createState() => _SuccesfulState();
}

class _SuccesfulState extends State<Succesful> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
      ),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
          const Center(
                child: Icon(Icons.check, color: Color.fromARGB(255, 58, 207, 63), size: 100,),
              ),
           const Text(
              "Login Successful",
              style: TextStyle(
                fontSize: 30,
                color: Colors.black,
                fontStyle: FontStyle.italic,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 80,),
             ElevatedButton(onPressed:(){
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> const GridViewScreen()));
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.black, foregroundColor: Colors.white,  shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0), 
                ),
                textStyle: const TextStyle(fontSize: 20),
                minimumSize: const Size(250, 50)
                ),
              child: const Text('Start Shopping'), ),
          ]
        )
      )
    );
  }
}