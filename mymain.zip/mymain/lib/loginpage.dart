import 'package:flutter/material.dart';
import 'package:mymain/log.dart';
import 'package:mymain/signup.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
      ),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min, 
          children: [
          const  Text(
              "SoleMate",
              style: TextStyle(
                fontSize: 40,
                color: Colors.black,
                 fontStyle: FontStyle.italic,
            fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 70), 
            ElevatedButton(
              onPressed: () {
                   Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> const Log()));
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.black, foregroundColor: Colors.white,  shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0), 
                ),
                textStyle: const TextStyle(fontSize: 20),
                minimumSize: const Size(250, 50)
                ),
              child: const Text('Login'),
            ),
          const  SizedBox(height: 10,),
          ElevatedButton(
              onPressed: () {
                   Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> const Signup()));
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black,  shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0), 
                ),
                textStyle: const TextStyle(fontSize: 20),
                minimumSize: const Size(250, 50)
                ),
              child: const Text('Sign Up'),
            ),
          ],
        ),
      ),
    );
  }
}
