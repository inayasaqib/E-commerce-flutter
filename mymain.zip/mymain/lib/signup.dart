import 'package:flutter/material.dart';
import 'package:mymain/succesful.dart';

class Signup extends StatefulWidget {
  const Signup({super.key});
  @override
  State<Signup> createState() => _SignupState();
}
class _SignupState extends State<Signup> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController passController = TextEditingController();
  final TextEditingController userController = TextEditingController();
  bool usernameValid = false;
  final RegExp usernameRegex = RegExp(r'^[a-zA-Z0-9_.-]{6,}$'); 

  void validateUsername(String username) {
    setState(() {
      usernameValid = usernameRegex.hasMatch(username);
    });
  }

  bool emailValid = false;
  String? passwordError;

  void validateemail(String email) {
    setState(() {
       emailValid = email.isNotEmpty && email.endsWith('@gmail.com');
    });
  }

  void validpass (password){
         setState(() {
      passwordError = passwordController.text.isEmpty
          ? 'Password cannot be empty'
          : passwordController.text != passwordController.text
              ? 'Passwords do not match'
              : null;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
      ),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              "SoleMate",
              style: TextStyle(
                fontSize: 30,
                color: Colors.black,
                fontStyle: FontStyle.italic,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 30.0),
            const Text(
              "Sign Up",
              style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.bold,
                fontSize: 20.0,
              ),
            ),
            const Text(
              "Create an new account",
              style: TextStyle(
                fontSize: 15.0,
                color: Color.fromARGB(255, 168, 166, 166),
              ),
            ),
              Container(
              padding: const EdgeInsets.symmetric(horizontal: 50.0),
              child: TextField(
                controller: userController,
                decoration: InputDecoration(
                  labelText: 'Username',
                  suffixIcon: usernameValid
                      ? const Icon(Icons.check)
                      : null,
                  errorText: usernameValid ? null : 'Username must be at least 6 characters long and should contain letters and numbers only',
                ),
                onChanged: (username) => validateUsername(username),
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 50.0),
              child: TextField(
                controller: emailController,
                decoration: InputDecoration(
                  labelText: 'Email',
                  suffixIcon: emailValid
                      ? const Icon(Icons.check)
                      : null,
                  errorText: emailValid ? null : 'Please Enter Valid Gmail Adress',
                ),
                onChanged: (email) => validateemail(email),
              ),
            ),
            Container(
                padding: const EdgeInsets.symmetric(horizontal: 50.0),
              child: TextField(
                controller: passwordController,
                decoration: const InputDecoration(
                  labelText: 'Password',
                ),
              ),
            ),
            Container(
                padding: const EdgeInsets.symmetric(horizontal: 50.0),
              child: TextField(
                controller: passController,
                decoration: const InputDecoration(
                  labelText: 'Confirm Password',
                    errorText: "Rewrite the password to Confirm",
                ),
                obscureText: true,
                onChanged: (password) => validpass(password),
              ),
            ),
            const  SizedBox(height: 20,),
            ElevatedButton(onPressed: emailValid && passwordError ==null? (){
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=> const Succesful()));
            } :null, 
            style: ElevatedButton.styleFrom(backgroundColor: Colors.black, foregroundColor: Colors.white,  shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0), 
                ),
                textStyle: const TextStyle(fontSize: 20),
                minimumSize: const Size(250, 50)
                ),
              child: const Text('Login'), ),
          ]
      )
      )
    );
  }
}